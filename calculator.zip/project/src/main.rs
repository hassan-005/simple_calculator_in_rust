enum Operation {
    Addition,
    Subtraction,
    Multiply,
    Division,
}
//fn calculate (operator: Operation) -> f64{
    

//}



use std::io::stdin ;

fn main() {
    let mut number1= String::new();
    let mut number2= String::new();
    let mut operator = String::new();
    println!("Enter the first number: ");
    stdin().read_line(&mut number1).expect("error");
    println!("Enter the Operation symbol: ");
    stdin().read_line(&mut operator).expect("error");
    println!("Enter the second number: ");
    stdin().read_line(&mut number2).expect("error");
    //println!("{} {} {}", number1, number2, operator);
    let symbol: char = match operator.trim().parse(){
        Ok(ch) => ch,
        Err(_) => return
    };
    let num1:f64 = match number1.trim().parse(){
        Ok(num) => num,
        Err(_) =>  return
    };
    let num2 : f64 = match number2.trim().parse(){
        Ok(num) =>num,
        Err(_) => return
    };
    println!("{}",operator);
    let operation  = match operator.as_str() {
        "+" => Operation::Addition,
        "-" => Operation::Subtraction,
        "*" => Operation::Multiply,
        "/" =>  Operation::Division,
        
    };
    match operation{
        Operation::Addition => println!("Addition"),
        _ => println!("other")
    }  ;  
}
